/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Message;
import model.User;

/**
 *
 * @author SAP-LAP-FPT
 */
public class MessageDBContext extends DBContext {
    public ArrayList<Message> getMessage(String to)
    {
        String sql = "SELECT [messageid]\n" +
                    "      ,[messagetitle]\n" +
                    "      ,[messagetime]\n" +
                    "      ,[from]\n" +
                    "      ,[to]\n" +
                    "      ,[messagecontent]\n" +
                    "      ,[isread]\n" +
                    "  FROM [MessageTBL] WHERE [to] = ?";
        
         ArrayList<Message> messages = new ArrayList<>();
        try {
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, to);
            ResultSet rs = stm.executeQuery();
            while(rs.next())
            {
                Message message = new Message();
                message.setId(rs.getInt("messageid"));
                message.setTitle(rs.getString("messagetitle"));
                message.setTime(rs.getTimestamp("messagetime"));
                User from = new User();
                from.setUserid((rs.getString("from")));
                message.setFrom(from);
                message.setContent(rs.getString("messagecontent"));
                message.setRead(rs.getBoolean("isread"));
                messages.add(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MessageDBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
        return messages;
    }
    public void insert(Message message)
    {
        try {
            String sql = "INSERT INTO [MessageTBL]\n" +
                    "           ([messagetitle]\n" +
                    "           ,[messagetime]\n" +
                    "           ,[from]\n" +
                    "           ,[to]\n" +
                    "           ,[messagecontent]\n" +
                    "           ,[isread])\n" +
                    "     VALUES\n" +
                    "           (?\n" +
                    "           ,GETDATE()\n" +
                    "           ,?\n" +
                    "           ,?\n" +
                    "           ,?\n" +
                    "           ,0)";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, message.getTitle());
            stm.setString(2, message.getFrom().getUserid());
            stm.setString(3, message.getTo().getUserid());
            stm.setString(4, message.getContent());
            stm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(MessageDBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
