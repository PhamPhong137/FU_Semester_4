/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dal.AccountDBContext;
import dal.MessageDBContext;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Message;
import model.User;

/**
 *
 * @author SAP-LAP-FPT
 */
public class CreateController extends BaseAuthController {

    @Override
    protected void processGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AccountDBContext db = new AccountDBContext();
        User user = (User)request.getSession().getAttribute("account");
        ArrayList<User> users = db.getAccountsExcept(user.getUserid());
        request.setAttribute("users", users);
        request.getRequestDispatcher("view/create.jsp").forward(request, response);
    }

    @Override
    protected void processPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User from = (User)request.getSession().getAttribute("account");
        String toid = request.getParameter("to");
        User to = new User();
        to.setUserid(toid);
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        
        Message message = new Message();
        message.setTitle(title);
        message.setContent(content);
        message.setFrom(from);
        message.setTo(to);
        
        MessageDBContext db = new MessageDBContext();
        db.insert(message);
        response.getWriter().println("done!");
    }

  
}
